from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from datetime import UTC, datetime
import hashlib
import json
import secrets
import threading
import time
from typing import Any, Protocol

import httpx
from .signing import ED25519, b64u_encode, canonical_device_proof, canonical_service_request, private_key, verify_device_signature


class ReplayStore(Protocol):
    """Atomic replay guard used when authorization cache is enabled.

    Implementations must return True exactly once for a key until ``expires_at`` and
    False for a duplicate. Multi-worker/multi-host deployments should provide a
    shared implementation backed by their infrastructure (for example Redis).
    """

    def consume(self, key: str, *, expires_at: float) -> bool: ...


class MemoryReplayStore:
    """Thread-safe single-process replay store.

    This is appropriate only when all requests for the protected service are handled
    in one Python process. It is deliberately explicit so clustered deployments do
    not accidentally assume process-local replay protection is global.
    """

    def __init__(self, *, max_entries: int = 100_000):
        if max_entries < 1:
            raise ValueError("max_entries must be > 0")
        self.max_entries = max_entries
        self._entries: OrderedDict[str, float] = OrderedDict()
        self._lock = threading.Lock()

    def consume(self, key: str, *, expires_at: float) -> bool:
        now = time.time()
        with self._lock:
            expired_keys = [k for k, expiry in self._entries.items() if expiry <= now]
            for expired_key in expired_keys:
                self._entries.pop(expired_key, None)
            expiry = self._entries.get(key)
            if expiry is not None and expiry > now:
                return False
            self._entries[key] = expires_at
            self._entries.move_to_end(key)
            while len(self._entries) > self.max_entries:
                self._entries.popitem(last=False)
            return True


@dataclass(frozen=True)
class _CacheEntry:
    response: dict[str, Any]
    expires_monotonic: float


class LicenseServerClient:
    """Server-to-server client using Ed25519 request signatures.

    Device authorization caching is opt-in and fail-closed. When enabled, the first
    successful remote check caches the owning device public key and license decision.
    Every cache hit still verifies the *current* business request's device signature,
    timestamp and nonce locally. A replay store is mandatory whenever cache is enabled.

    Automatic HTTP retries are intentionally not performed. Device and service proofs
    contain one-time nonces; an ambiguous network failure must be retried with fresh
    proofs by the caller.
    """

    def __init__(
        self,
        base_url: str,
        key_id: str,
        private_key_b64: str,
        *,
        audience: str | None = None,
        timeout: float = 3.0,
        verify: bool | str = True,
        cert: Any = None,
        cache_ttl_seconds: int = 0,
        cache_max_entries: int = 10_000,
        max_device_proof_skew_seconds: int = 120,
        replay_store: ReplayStore | None = None,
        transport: httpx.BaseTransport | None = None,
    ):
        if cache_ttl_seconds < 0 or cache_ttl_seconds > 300:
            raise ValueError("cache_ttl_seconds must be between 0 and 300")
        if cache_max_entries < 1:
            raise ValueError("cache_max_entries must be > 0")
        if max_device_proof_skew_seconds < 30 or max_device_proof_skew_seconds > 600:
            raise ValueError("max_device_proof_skew_seconds must be between 30 and 600")
        if cache_ttl_seconds and not audience:
            raise ValueError("audience is required when authorization cache is enabled")
        if cache_ttl_seconds and replay_store is None:
            raise ValueError("replay_store is required when authorization cache is enabled")

        self.base_url = base_url.rstrip('/')
        self.key_id = key_id
        self.audience = audience
        self.private = private_key(private_key_b64)
        self.cache_ttl_seconds = cache_ttl_seconds
        self.cache_max_entries = cache_max_entries
        self.max_device_proof_skew_seconds = max_device_proof_skew_seconds
        self.replay_store = replay_store
        self._cache: OrderedDict[str, _CacheEntry] = OrderedDict()
        self._cache_lock = threading.Lock()
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=httpx.Timeout(timeout),
            verify=verify,
            cert=cert,
            transport=transport,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def _post(self, path: str, payload: dict):
        body = json.dumps(payload, separators=(',', ':'), ensure_ascii=False).encode()
        ts = int(time.time())
        nonce = secrets.token_urlsafe(24)
        msg = canonical_service_request('POST', path, body, ts, nonce, self.key_id)
        sig = b64u_encode(self.private.sign(msg))
        headers = {
            'Content-Type': 'application/json',
            'X-License-Key-Id': self.key_id,
            'X-License-Timestamp': str(ts),
            'X-License-Nonce': nonce,
            'X-License-Signature': sig,
        }
        response = self._client.post(path, content=body, headers=headers)
        response.raise_for_status()
        return response.json()

    def activate(self, payload: dict):
        return self._post('/v1/activate', payload)

    def check(self, payload: dict):
        return self._post('/v1/check', payload)

    def check_device_entitlement(self, device_id: str) -> dict[str, Any]:
        """Check a previously activated device for this service tenant.

        This is the server-to-server background-operation contract. It deliberately
        sends only ``device_id``; the tenant is selected by the Service Credential
        and no Device Proof is involved. Any transport, HTTP, or malformed-response
        failure is returned as UNKNOWN so callers cannot fail open.
        """
        try:
            result = self._post('/v1/entitlements/check', {'device_id': device_id})
        except httpx.HTTPStatusError as exc:
            return self._unknown('LICENSE_SERVICE_REJECTED', http_status=exc.response.status_code)
        except httpx.RequestError:
            return self._unknown('LICENSE_SERVICE_UNAVAILABLE')
        except Exception:
            # JSON/protocol/configuration failures are authorization uncertainty.
            return self._unknown('LICENSE_SERVICE_INVALID_RESPONSE')

        decision = str(result.get('decision', '')).upper()
        # Accept the explicit v1 decision field. The boolean compatibility fallback
        # is only for early SDK test doubles; the License Service response is always
        # normalized to the decision contract above.
        if decision not in {'ACTIVE', 'INACTIVE'}:
            if isinstance(result.get('active'), bool):
                decision = 'ACTIVE' if result['active'] else 'INACTIVE'
            elif isinstance(result.get('activated'), bool):
                decision = 'ACTIVE' if result['activated'] else 'INACTIVE'
            else:
                return self._unknown('LICENSE_SERVICE_INVALID_RESPONSE')
        normalized = dict(result)
        # rc4 carries the complete License Context.  Keep compatibility with
        # the pre-entitlement test doubles used by older integrations, while
        # rejecting partially populated new contexts rather than silently
        # handing a business service an ambiguous authorization result.
        if decision == 'ACTIVE':
            context_fields = {'license_id', 'device_id', 'plan', 'entitlement_schema_version', 'entitlements'}
            present = context_fields.intersection(normalized)
            if present and not context_fields.issubset(normalized):
                return self._unknown('LICENSE_SERVICE_INVALID_RESPONSE')
            if not present:
                normalized['device_id'] = device_id
        normalized.update({'decision': decision, 'activated': decision == 'ACTIVE', 'source': 'remote'})
        return normalized

    def check_entitlement(self, device_id: str) -> dict[str, Any]:
        """rc4 spelling for the background entitlement check."""

        return self.check_device_entitlement(device_id)

    def invalidate_device(self, device_id: str) -> None:
        with self._cache_lock:
            self._cache.pop(device_id, None)

    def clear_cache(self) -> None:
        with self._cache_lock:
            self._cache.clear()

    def cache_size(self) -> int:
        with self._cache_lock:
            self._purge_cache_locked()
            return len(self._cache)

    def _purge_cache_locked(self) -> None:
        now = time.monotonic()
        expired = [key for key, entry in self._cache.items() if entry.expires_monotonic <= now]
        for key in expired:
            self._cache.pop(key, None)
        while len(self._cache) > self.cache_max_entries:
            self._cache.popitem(last=False)

    @staticmethod
    def _license_expiry_epoch(value: Any) -> float | None:
        if not value:
            return None
        if isinstance(value, datetime):
            dt = value
        else:
            text = str(value)
            if text.endswith('Z'):
                text = text[:-1] + '+00:00'
            dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        return dt.astimezone(UTC).timestamp()

    def _cache_remote_active(self, device_id: str, response: dict[str, Any]) -> None:
        if not self.cache_ttl_seconds or not response.get('activated'):
            return
        if not response.get('device_public_key') or not response.get('device_key_algorithm'):
            return
        ttl = float(self.cache_ttl_seconds)
        license_expiry = self._license_expiry_epoch(response.get('expires_at'))
        if license_expiry is not None:
            ttl = min(ttl, max(0.0, license_expiry - time.time()))
        if ttl <= 0:
            return
        entry = _CacheEntry(response=dict(response), expires_monotonic=time.monotonic() + ttl)
        with self._cache_lock:
            self._cache[device_id] = entry
            self._cache.move_to_end(device_id)
            self._purge_cache_locked()

    def _cached_entry(self, device_id: str) -> _CacheEntry | None:
        if not self.cache_ttl_seconds:
            return None
        with self._cache_lock:
            self._purge_cache_locked()
            entry = self._cache.get(device_id)
            if entry:
                self._cache.move_to_end(device_id)
            return entry

    def _verify_cached_device_proof(
        self,
        *,
        device_id: str,
        request_method: str,
        request_target: str,
        body_sha256: str,
        device_proof: dict,
        public_key_b64: str,
        key_algorithm: str,
    ) -> tuple[bool, str]:
        try:
            ts = int(device_proof['timestamp'])
            nonce = str(device_proof['nonce'])
            signature = str(device_proof['signature'])
        except (KeyError, TypeError, ValueError):
            return False, 'INVALID_DEVICE_PROOF'
        if abs(int(time.time()) - ts) > self.max_device_proof_skew_seconds:
            return False, 'DEVICE_PROOF_EXPIRED'
        if len(nonce) < 16 or len(nonce) > 128:
            return False, 'INVALID_DEVICE_PROOF'
        message = canonical_device_proof(
            self.audience,
            key_algorithm,
            request_method,
            request_target,
            body_sha256,
            ts,
            nonce,
        )
        if not verify_device_signature(public_key_b64, key_algorithm, message, signature):
            return False, 'INVALID_DEVICE_PROOF'
        if self.replay_store is None:
            return False, 'CACHE_REPLAY_GUARD_UNAVAILABLE'
        replay_key = hashlib.sha256(f'{self.audience}:{device_id}:{nonce}'.encode()).hexdigest()
        if not self.replay_store.consume(
            replay_key,
            expires_at=ts + self.max_device_proof_skew_seconds * 2,
        ):
            return False, 'DEVICE_PROOF_REPLAYED'
        return True, 'ACTIVE'

    @staticmethod
    def _unknown(reason: str, *, http_status: int | None = None) -> dict[str, Any]:
        result: dict[str, Any] = {
            'activated': False,
            'reason': reason,
            'decision': 'UNKNOWN',
            'source': 'fail_closed',
        }
        if http_status is not None:
            result['http_status'] = http_status
        return result

    def check_device_request(
        self,
        *,
        device_id: str,
        request_method: str,
        request_target: str,
        raw_body: bytes,
        device_proof: dict,
        device_key_algorithm: str = ED25519,
    ) -> dict[str, Any]:
        body_sha256 = hashlib.sha256(raw_body).hexdigest()
        cached = self._cached_entry(device_id)
        if cached is not None:
            ok, reason = self._verify_cached_device_proof(
                device_id=device_id,
                request_method=request_method.upper(),
                request_target=request_target,
                body_sha256=body_sha256,
                device_proof=device_proof,
                public_key_b64=str(cached.response['device_public_key']),
                key_algorithm=str(cached.response['device_key_algorithm']),
            )
            if not ok:
                return {
                    'activated': False,
                    'reason': reason,
                    'decision': 'INACTIVE',
                    'source': 'cache',
                }
            result = dict(cached.response)
            result.update({'activated': True, 'reason': 'ACTIVE', 'decision': 'ACTIVE', 'source': 'cache'})
            return result

        payload = {
            'device_key_algorithm': device_key_algorithm,
            'device_id': device_id,
            'request_method': request_method.upper(),
            'request_target': request_target,
            'request_body_sha256': body_sha256,
            'proof': device_proof,
        }
        try:
            result = self._post('/v1/check', payload)
        except httpx.HTTPStatusError as exc:
            # Authentication/configuration failures remain fail-closed. The status is
            # preserved so operators can distinguish them from ordinary inactive state.
            return self._unknown('LICENSE_SERVICE_REJECTED', http_status=exc.response.status_code)
        except httpx.RequestError:
            return self._unknown('LICENSE_SERVICE_UNAVAILABLE')

        if result.get('activated'):
            # The remote License Service has already consumed this proof nonce. Mirror
            # it into the local/shared replay guard before populating the cache so an
            # immediate replay cannot switch from remote path to cache path and pass.
            if self.cache_ttl_seconds and self.replay_store is not None:
                try:
                    ts = int(device_proof['timestamp'])
                    nonce = str(device_proof['nonce'])
                    replay_key = hashlib.sha256(f'{self.audience}:{device_id}:{nonce}'.encode()).hexdigest()
                    if not self.replay_store.consume(
                        replay_key,
                        expires_at=ts + self.max_device_proof_skew_seconds * 2,
                    ):
                        return {
                            'activated': False,
                            'reason': 'DEVICE_PROOF_REPLAYED',
                            'decision': 'INACTIVE',
                            'source': 'remote',
                        }
                except (KeyError, TypeError, ValueError):
                    return {
                        'activated': False,
                        'reason': 'INVALID_DEVICE_PROOF',
                        'decision': 'INACTIVE',
                        'source': 'remote',
                    }
            result = dict(result)
            result.update({'decision': 'ACTIVE', 'device_id': device_id, 'source': 'remote'})
            if result.get('plan_code') is not None and result.get('plan_version') is not None:
                result.setdefault('plan', {'code': result['plan_code'], 'version': result['plan_version']})
            self._cache_remote_active(device_id, result)
            return result

        result = dict(result)
        result.update({'decision': 'INACTIVE', 'source': 'remote'})
        return result
