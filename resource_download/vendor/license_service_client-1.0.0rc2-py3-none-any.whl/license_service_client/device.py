from __future__ import annotations
import hashlib,secrets,time
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding,NoEncryption,PrivateFormat,PublicFormat
from .signing import ED25519,b64u_decode,b64u_encode,canonical_activation_proof,canonical_device_proof,private_key

def derive_device_id(public_key_b64:str,key_algorithm:str=ED25519)->str:
 raw=b64u_decode(public_key_b64)
 if key_algorithm!=ED25519:
  raise ValueError('Python key generator currently generates ED25519 device keys only')
 if len(raw)!=32:
  raise ValueError('Ed25519 public key must be 32 bytes')
 return 'dev_'+hashlib.sha256(raw).hexdigest()
def generate_device_keypair()->tuple[str,str]:
 p=Ed25519PrivateKey.generate();return b64u_encode(p.private_bytes(Encoding.Raw,PrivateFormat.Raw,NoEncryption())),b64u_encode(p.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw))
def generate_device_identity()->tuple[str,str,str]:
 private,public=generate_device_keypair();return derive_device_id(public),private,public
def activation_proof(private_key_b64,*,audience,license_key,device_id,public_key_b64,key_algorithm=ED25519):
 if key_algorithm!=ED25519:
  raise ValueError('activation_proof private-key helper supports ED25519 only')
 ts=int(time.time());nonce=secrets.token_urlsafe(24);msg=canonical_activation_proof(audience,key_algorithm,license_key,device_id,public_key_b64,ts,nonce);return {'timestamp':ts,'nonce':nonce,'signature':b64u_encode(private_key(private_key_b64).sign(msg))}
def request_proof(private_key_b64,*,audience,method,request_target,body_sha256,key_algorithm=ED25519):
 if key_algorithm!=ED25519:
  raise ValueError('request_proof private-key helper supports ED25519 only')
 ts=int(time.time());nonce=secrets.token_urlsafe(24);msg=canonical_device_proof(audience,key_algorithm,method,request_target,body_sha256,ts,nonce);return {'timestamp':ts,'nonce':nonce,'signature':b64u_encode(private_key(private_key_b64).sign(msg))}
