from __future__ import annotations
import base64,hashlib
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

SERVICE_SIGNATURE_VERSION='LS-SERVICE-V1'
DEVICE_SIGNATURE_VERSION='LS-DEVICE-V3'
ED25519='ED25519'
ECDSA_P256_SHA256='ECDSA_P256_SHA256'

def b64u_encode(data:bytes)->str:return base64.urlsafe_b64encode(data).decode().rstrip('=')
def b64u_decode(value:str)->bytes:return base64.urlsafe_b64decode((value+'='*(-len(value)%4)).encode())
def private_key(value:str)->Ed25519PrivateKey:
 raw=b64u_decode(value)
 if len(raw)!=32:raise ValueError('Ed25519 private key must be 32 bytes')
 return Ed25519PrivateKey.from_private_bytes(raw)
def canonical_service_request(method,path_and_query,body,timestamp,nonce,key_id):
 return '\n'.join([SERVICE_SIGNATURE_VERSION,method.upper(),path_and_query,hashlib.sha256(body).hexdigest(),str(timestamp),nonce,key_id]).encode()
def canonical_device_proof(audience,key_algorithm,method,request_target,body_sha256,timestamp,nonce):
 return '\n'.join([DEVICE_SIGNATURE_VERSION,audience,key_algorithm,method.upper(),request_target,body_sha256.lower(),str(timestamp),nonce]).encode()
def canonical_activation_proof(audience,key_algorithm,license_key,device_id,public_key,timestamp,nonce):
 return '\n'.join([DEVICE_SIGNATURE_VERSION,audience,key_algorithm,'ACTIVATE',license_key.strip().upper(),device_id.strip(),public_key,str(timestamp),nonce]).encode()
def verify_device_signature(public_key_b64,key_algorithm,message,signature_b64):
 try:
  raw=b64u_decode(public_key_b64);sig=b64u_decode(signature_b64)
  if len(sig)!=64:return False
  if key_algorithm==ED25519:
   if len(raw)!=32:return False
   Ed25519PublicKey.from_public_bytes(raw).verify(sig,message);return True
  if key_algorithm!=ECDSA_P256_SHA256:return False
  key=serialization.load_der_public_key(raw)
  if not isinstance(key,ec.EllipticCurvePublicKey) or not isinstance(key.curve,ec.SECP256R1):return False
  if key.public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)!=raw:return False
  r=int.from_bytes(sig[:32],'big');s=int.from_bytes(sig[32:],'big')
  if r<=0 or s<=0:return False
  key.verify(encode_dss_signature(r,s),message,ec.ECDSA(hashes.SHA256()));return True
 except (ValueError,InvalidSignature,TypeError):return False
